package com.example.fileparser;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;

import javax.swing.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

public class FileParserApp {
    private static final Logger logger = LogManager.getLogger(FileParserApp.class);

    public static void main(String[] args) {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(null);

        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            String filePath = selectedFile.getAbsolutePath();
            String fileExtension = getFileExtension(filePath);

            logger.info("Selected file: " + filePath);
            switch (fileExtension) {
                case "pdf":
                    parsePDF(filePath);
                    break;
                case "docx":
                    parseWord(filePath);
                    break;
                case "xlsx":
                    parseExcel(filePath);
                    break;
                case "csv":
                    parseCSV(filePath);
                    break;
                default:
                    logger.error("Unsupported file type: " + fileExtension);
                    break;
            }
        } else {
            logger.warn("No file selected.");
        }
    }

    private static String getFileExtension(String fileName) {
        int dotIndex = fileName.lastIndexOf('.');
        return (dotIndex == -1) ? "" : fileName.substring(dotIndex + 1);
    }

    private static void parsePDF(String filePath) {
        try (PDDocument document = PDDocument.load(new File(filePath))) {
            PDFTextStripper pdfStripper = new PDFTextStripper();
            String text = pdfStripper.getText(document);
            logger.info("PDF Content:\n" + text);
        } catch (IOException e) {
            logger.error("Error reading PDF file: " + e.getMessage(), e);
        }
    }

    private static void parseWord(String filePath) {
        try (FileInputStream fis = new FileInputStream(filePath);
             XWPFDocument document = new XWPFDocument(fis)) {
            for (XWPFParagraph paragraph : document.getParagraphs()) {
                logger.info(paragraph.getText());
            }
        } catch (IOException e) {
            logger.error("Error reading Word file: " + e.getMessage(), e);
        }
    }

    private static void parseExcel(String filePath) {
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(fis)) {
            Sheet sheet = workbook.getSheetAt(0);
            for (Row row : sheet) {
                for (Cell cell : row) {
                    logger.info(cell.toString() + "\t");
                }
                logger.info("");
            }
        } catch (IOException e) {
            logger.error("Error reading Excel file: " + e.getMessage(), e);
        }
    }

    private static void parseCSV(String filePath) {
        try (FileReader reader = new FileReader(filePath)) {
            Iterable<CSVRecord> records = CSVFormat.DEFAULT.parse(reader);
            for (CSVRecord record : records) {
                for (String field : record) {
                    logger.info(field + "\t");
                }
                logger.info("");
            }
        } catch (IOException e) {
            logger.error("Error reading CSV file: " + e.getMessage(), e);
        }
    }
}
